# discord-spam-for-pokecord-level
## DISCLAIMER
This is ONLY for use on your OWN server and it is (as far as I know) within the rules of discord.
This bot does NOT:
* respond or react to other user's actions;respond to commands, autoreply to certain keywords, welcome users to servers, automatically react, etc. YOU are the only one that can control it.
* 'invite scraping'
* spam, insult or demean others, post NSFW material, spread viruses or illegal material, etc.

## Features
The bot will spam the channel with random text. This will help level your pokemon on the discord pokecord game.

## Usage
run `node bot.js` in the bash terminal.
press Ctr + C to stop the bot from running

## Current version 
`!spam 3` will make the bot spam "<3" 9 times with 800miliseconds in between. It will then wait for 5 seconds and repeat the spam loop 3 times. NOTE: change the number 3 to any other larger number for more spams

## Fixes and improvements
* Generate random text (to replace "<3") for spamming (maybe random jokes too?)
